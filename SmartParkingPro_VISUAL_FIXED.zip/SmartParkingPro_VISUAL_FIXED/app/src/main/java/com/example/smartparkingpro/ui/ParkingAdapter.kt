
package com.example.smartparkingpro.ui

import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.smartparkingpro.Parking
import com.example.smartparkingpro.R

class ParkingAdapter(
    private val items: List<Parking>,
    private val onClick: (Parking) -> Unit
) : RecyclerView.Adapter<ParkingAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.parkingImage)
        val name: TextView = view.findViewById(R.id.name)
        val info: TextView = view.findViewById(R.id.info)
        val progressBar: ProgressBar = view.findViewById(R.id.availabilityBar)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_parking, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val parking = items[position]

        holder.image.setImageResource(parking.imageRes)
        holder.name.text = parking.name
        holder.info.text = "Places: ${parking.available}/${parking.total}"

        val percentage = (parking.available * 100) / parking.total
        holder.progressBar.progress = percentage

        when {
            percentage > 50 -> holder.progressBar.progressTintList =
                ColorStateList.valueOf(Color.parseColor("#4CAF50"))
            percentage > 20 -> holder.progressBar.progressTintList =
                ColorStateList.valueOf(Color.parseColor("#FFC107"))
            else -> holder.progressBar.progressTintList =
                ColorStateList.valueOf(Color.parseColor("#F44336"))
        }

        holder.itemView.setOnClickListener { onClick(parking) }
    }

    override fun getItemCount() = items.size
}
