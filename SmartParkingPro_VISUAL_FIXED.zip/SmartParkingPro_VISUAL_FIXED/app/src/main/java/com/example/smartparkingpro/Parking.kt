
package com.example.smartparkingpro

data class Parking(
    val name: String,
    val address: String,
    val total: Int,
    val available: Int,
    val price: Double,
    val imageRes: Int
)
