
package com.example.smartparkingpro.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.smartparkingpro.Parking
import com.example.smartparkingpro.R

class ParkingListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)

        val parkings = listOf(
            Parking("Centre Ville", "12 Rue de Paris", 100, 60, 2.5, R.drawable.parking1),
            Parking("Gare", "5 Avenue Gare", 200, 15, 3.0, R.drawable.parking2),
            Parking("Université", "Campus Nord", 150, 90, 1.5, R.drawable.parking3)
        )

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = ParkingAdapter(parkings) {
            val intent = Intent(this, ParkingDetailActivity::class.java)
            intent.putExtra("name", it.name)
            intent.putExtra("address", it.address)
            intent.putExtra("total", it.total)
            intent.putExtra("available", it.available)
            intent.putExtra("price", it.price)
            intent.putExtra("imageRes", it.imageRes)
            startActivity(intent)
        }
    }
}
